package com.sliit.mtit.microservice.SellerServiceIT16076594;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SellerServiceIt16076594Application {

	public static void main(String[] args) {
		SpringApplication.run(SellerServiceIt16076594Application.class, args);
	}

}
