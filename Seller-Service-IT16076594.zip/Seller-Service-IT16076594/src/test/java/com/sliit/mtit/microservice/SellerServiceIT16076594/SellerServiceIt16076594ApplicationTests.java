package com.sliit.mtit.microservice.SellerServiceIT16076594;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SellerServiceIt16076594ApplicationTests {

	@Test
	void contextLoads() {
	}

}
