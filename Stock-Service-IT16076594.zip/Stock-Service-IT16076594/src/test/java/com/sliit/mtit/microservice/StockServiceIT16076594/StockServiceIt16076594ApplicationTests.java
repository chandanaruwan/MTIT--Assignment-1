package com.sliit.mtit.microservice.StockServiceIT16076594;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockServiceIt16076594ApplicationTests {

	@Test
	void contextLoads() {
	}

}
