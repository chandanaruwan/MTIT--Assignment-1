package com.sliit.mtit.microservice.StockServiceIT16076594;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockServiceIt16076594Application {

	public static void main(String[] args) {
		SpringApplication.run(StockServiceIt16076594Application.class, args);
	}

}
